import tkinter as tk
from tkinter import messagebox, font
import random
import pygame
import numpy as np
import time
import os
import webbrowser
import sys

try:
    import qrcode
    from PIL import Image, ImageTk
    QR_AVAILABLE = True
except ImportError:
    QR_AVAILABLE = False
    print("⚠️ QR Code library not installed. Install with: pip install qrcode[pil]")

class FilipinoGuessingGame:
    def __init__(self, root):
        self.root = root
        self.root.title("🎯 Hulaan Mo! - Barangay Fiesta Edition")
        self.root.attributes('-fullscreen', True)
        self.root.resizable(False, False)
        self.root.configure(bg='#f8f1e0')
        
        # Get dynamic screen dimensions
        self.screen_width = self.root.winfo_screenwidth()
        self.screen_height = self.root.winfo_screenheight()
        
        # Bind Escape key to exit fullscreen
        self.root.bind('<Escape>', lambda e: self.toggle_fullscreen())
        self.root.bind('<F11>', lambda e: self.toggle_fullscreen())
        
        # Initialize pygame mixer
        try:
            pygame.mixer.init()
            self.sound_enabled = True
        except:
            self.sound_enabled = False
            print("⚠️ Sound disabled - pygame mixer initialization failed")
        
        # Game variables
        self.secret_number = random.randint(1, 100)
        self.attempts = 0
        self.max_attempts = 10
        self.game_over = False
        self.confetti_particles = []
        self.confetti_active = False
        self.confetti_animation_id = None
        self.failure_effects_active = False
        self.fullscreen = True
        self.high_score = self.load_high_score()
        
        # QR Code URL - CHANGE THIS TO YOUR GAME PAGE URL
        self.game_url = "https://gamers12345.itch.io/hulaan-game"  # ← CHANGE THIS!
        
        # Filipino number words
        self.filipino_numbers = {
            1: 'isa', 2: 'dalawa', 3: 'tatlo', 4: 'apat', 5: 'lima',
            6: 'anim', 7: 'pito', 8: 'walo', 9: 'siyam', 10: 'sampu',
            11: 'labing-isa', 12: 'labindalawa', 13: 'labintatlo',
            14: 'labing-apat', 15: 'labinlima', 16: 'labing-anim',
            17: 'labimpito', 18: 'labingwalo', 19: 'labinsiyam', 
            20: 'dalawampu', 30: 'tatlumpu', 40: 'apatnapu', 
            50: 'limampu', 60: 'animnapu', 70: 'pitumpu', 
            80: 'walumpu', 90: 'siyamnapu', 100: 'isang daan'
        }
        
        # Filipino food items as prizes
        self.filipino_items = [
            "🥭 Manga (Mango)",
            "🍢 Isda (Fish)",
            "🥟 Lumpia",
            "🍖 Lechon",
            "🍨 Halo-Halo",
            "🥖 Pandesal",
            "🍌 Saging (Banana)",
            "🥥 Buko (Coconut)",
            "🍛 Adobo",
            "🍜 Pancit"
        ]
        
        self.current_item = random.choice(self.filipino_items)
        
        # Track guess history with Filipino numbers
        self.guess_history = []
        
        # Create sounds
        self.create_sounds()
        
        # Set up UI with fiesta banner and QR code
        self.setup_ui()
        
        # Play start sound
        self.play_start_sound()
        
        # Add Filipino cultural background
        self.add_cultural_background()
        
        # Animate banner periodically
        self.animate_banner()
    
    def toggle_fullscreen(self):
        """Toggle fullscreen mode"""
        self.fullscreen = not self.fullscreen
        self.root.attributes('-fullscreen', self.fullscreen)
    
    def load_high_score(self):
        """Load high score from file"""
        try:
            if os.path.exists('highscore.txt'):
                with open('highscore.txt', 'r') as f:
                    return int(f.read().strip())
        except:
            pass
        return None
    
    def save_high_score(self, score):
        """Save high score to file"""
        try:
            with open('highscore.txt', 'w') as f:
                f.write(str(score))
        except:
            pass
    
    def create_sounds(self):
        """Create sound effects"""
        try:
            self.start_sound = self.generate_tone(440, 0.3, 'ascending')
            self.win_sound = self.generate_tone(523, 0.5, 'victory')
            self.lose_sound = self.generate_tone(200, 0.5, 'descending')
            self.guess_sound = self.generate_tone(600, 0.05, 'click')
            self.hint_sound = self.generate_tone(880, 0.15, 'chime')
            self.newgame_sound = self.generate_tone(523, 0.15, 'chime')
            self.boom_sound = self.generate_tone(100, 0.3, 'boom')
            print("✅ Sounds created successfully!")
        except Exception as e:
            self.start_sound = None
            self.win_sound = None
            self.lose_sound = None
            self.guess_sound = None
            self.hint_sound = None
            self.newgame_sound = None
            self.boom_sound = None
            print(f"Note: Sound effects disabled: {e}")
    
    def generate_tone(self, frequency, duration, pattern='simple'):
        """Generate a simple tone"""
        try:
            sample_rate = 44100
            t = np.linspace(0, duration, int(sample_rate * duration))
            
            if pattern == 'ascending':
                freq_sweep = np.linspace(frequency * 0.5, frequency * 2, len(t))
                wave = np.sin(2 * np.pi * freq_sweep * t) * np.exp(-3 * t)
            elif pattern == 'descending':
                freq_sweep = np.linspace(frequency * 2, frequency * 0.5, len(t))
                wave = np.sin(2 * np.pi * freq_sweep * t) * np.exp(-2 * t)
            elif pattern == 'click':
                wave = np.sin(2 * np.pi * frequency * t) * np.exp(-20 * t)
            elif pattern == 'chime':
                wave = np.sin(2 * np.pi * frequency * t) * np.exp(-3 * t)
                wave += 0.5 * np.sin(2 * np.pi * frequency * 2 * t) * np.exp(-5 * t)
            elif pattern == 'boom':
                wave = np.sin(2 * np.pi * frequency * t) * np.exp(-8 * t)
                wave += 0.3 * np.sin(2 * np.pi * frequency * 0.5 * t) * np.exp(-10 * t)
            elif pattern == 'victory':
                # Simple victory melody
                wave = np.sin(2 * np.pi * frequency * t) * np.exp(-3 * t)
                wave += 0.5 * np.sin(2 * np.pi * frequency * 1.5 * t) * np.exp(-4 * t)
                wave += 0.3 * np.sin(2 * np.pi * frequency * 2 * t) * np.exp(-5 * t)
            else:
                wave = np.sin(2 * np.pi * frequency * t) * np.exp(-3 * t)
            
            wave = np.int16(wave * 32767 * 0.3)
            wave = np.ascontiguousarray(wave)
            
            stereo_wave = np.array([wave, wave]).T
            stereo_wave = np.ascontiguousarray(stereo_wave)
            
            return pygame.sndarray.make_sound(stereo_wave)
        except Exception as e:
            print(f"Error generating tone: {e}")
            return None
    
    def play_sound(self, sound):
        """Play a sound if it exists"""
        if self.sound_enabled and sound:
            try:
                sound.play()
            except:
                pass
    
    def play_start_sound(self):
        self.play_sound(self.start_sound)
        self.pulse_effect()
    
    def play_win_sound(self):
        self.play_sound(self.win_sound)
        self.root.after(100, self.start_confetti)
    
    def play_lose_sound(self):
        self.play_sound(self.lose_sound)
        self.root.after(100, self.start_failure_effects)
    
    def play_guess_sound(self):
        self.play_sound(self.guess_sound)
    
    def play_hint_sound(self):
        self.play_sound(self.hint_sound)
    
    def pulse_effect(self):
        """Create a pulsing effect on the title"""
        colors = ['#0032a0', '#ce1126', '#f1c40f', '#0032a0']
        for color in colors:
            self.title_label.config(fg=color)
            self.root.update()
            self.root.after(150)
    
    def add_cultural_background(self):
        """Add Filipino cultural elements"""
        proverbs = [
            "🇵🇭 'Ang hindi marunong lumingon sa pinanggalingan ay hindi makararating sa paroroonan.'",
            "🇵🇭 'Kung may tiyaga, may nilaga.'",
            "🇵🇭 'Ang buhay ay parang gulong, minsan nasa ibabaw, minsan nasa ilalim.'",
            "🇵🇭 'Nasa Diyos ang awa, nasa tao ang gawa.'"
        ]
        self.quote_label = tk.Label(
            self.root,
            text=random.choice(proverbs),
            font=('Arial', 10, 'italic'),
            bg='#f8f1e0',
            fg='#8b7355'
        )
        self.quote_label.pack(side='bottom', pady=10)
        
        # Developer credit
        credit_label = tk.Label(
            self.root,
            text="🎮 Developed by: [Your Name] | BSIT - [Section]",
            font=('Arial', 8),
            bg='#f8f1e0',
            fg='#95a5a6'
        )
        credit_label.pack(side='bottom', pady=(0, 5))
    
    def animate_banner(self):
        """Animate the fiesta banner with moving stars"""
        if hasattr(self, 'banner_canvas'):
            # Move stars randomly
            try:
                # Find all star items and move them slightly
                items = self.banner_canvas.find_all()
                for item in items:
                    if self.banner_canvas.type(item) == 'text':
                        text = self.banner_canvas.itemcget(item, 'text')
                        if text in ['⭐', '✨', '🌟']:
                            dx = random.randint(-2, 2)
                            dy = random.randint(-2, 2)
                            self.banner_canvas.move(item, dx, dy)
            except:
                pass
        
        # Schedule next animation
        self.root.after(2000, self.animate_banner)
    
    def create_fiesta_banner(self, parent):
        """Create a colorful Filipino fiesta banner with banderitas"""
        banner_frame = tk.Frame(parent, bg='#f8f1e0', height=65)
        banner_frame.pack(fill='x', pady=(5, 0))
        banner_frame.pack_propagate(False)
        
        # Create a canvas for the banner
        self.banner_canvas = tk.Canvas(
            banner_frame,
            height=65,
            bg='#f8f1e0',
            highlightthickness=0
        )
        self.banner_canvas.pack(fill='x')
        
        # Draw the banderitas (triangular flags)
        banner_width = self.screen_width
        num_flags = 15
        flag_width = banner_width // num_flags
        colors = ['#ce1126', '#0032a0', '#f1c40f', '#ce1126', '#0032a0', '#f1c40f']
        
        self.banner_flags = []
        for i in range(num_flags):
            x1 = i * flag_width
            x2 = x1 + flag_width
            y1 = 5
            y2 = 55
            
            color = colors[i % len(colors)]
            
            # Draw triangular flag
            flag = self.banner_canvas.create_polygon(
                x1, y1,
                x1 + flag_width//2, y2,
                x1 + flag_width, y1,
                fill=color,
                outline='white',
                width=1,
                tags='flag'
            )
            self.banner_flags.append(flag)
            
            # Add small decorations on the flag
            if i % 2 == 0:
                self.banner_canvas.create_text(
                    x1 + flag_width//2,
                    y1 + 22,
                    text=random.choice(['★', '✨', '🎉', '🎊', '❤️', '🇵🇭']),
                    font=('Arial', 10),
                    fill='white',
                    tags='decoration'
                )
        
        # Add a string/rope connecting the flags
        self.banner_canvas.create_line(
            0, 5,
            banner_width, 5,
            fill='#8b7355',
            width=2,
            dash=(3, 3),
            tags='rope'
        )
        
        # Add festive text in the middle
        self.banner_canvas.create_text(
            banner_width // 2,
            5,
            text="🎊 MALIGAYANG BARANGAY FIESTA! 🎊",
            font=('Arial', 13, 'bold'),
            fill='#ce1126',
            anchor='n',
            tags='banner_text'
        )
        
        # Add small star decorations
        self.banner_stars = []
        for i in range(10):
            x = random.randint(20, banner_width - 20)
            y = random.randint(30, 58)
            star = self.banner_canvas.create_text(
                x, y,
                text=random.choice(['⭐', '✨', '🌟']),
                font=('Arial', random.randint(10, 16)),
                tags='star'
            )
            self.banner_stars.append(star)
        
        # Add a subtle glow effect (optional)
        self.banner_canvas.create_rectangle(
            0, 0,
            banner_width, 5,
            fill='#f1c40f',
            stipple='gray25',
            tags='glow'
        )
        
        return banner_frame
    
    def create_qr_code(self, parent):
        """Create a QR code for the game page"""
        qr_frame = tk.Frame(parent, bg='#f8f1e0')
        qr_frame.pack(pady=5)
        
        # QR Code label
        qr_label = tk.Label(
            qr_frame,
            text="📱 I-SCAN MO AKO!",
            font=('Arial', 10, 'bold'),
            bg='#f8f1e0',
            fg='#0032a0'
        )
        qr_label.pack()
        
        if QR_AVAILABLE and self.game_url:
            try:
                # Generate QR code
                qr = qrcode.QRCode(
                    version=2,
                    error_correction=qrcode.constants.ERROR_CORRECT_H,
                    box_size=6,
                    border=2,
                )
                qr.add_data(self.game_url)
                qr.make(fit=True)
                
                # Create QR image with Filipino colors
                qr_img = qr.make_image(fill_color="#0032a0", back_color="#f8f1e0")
                
                # Convert to PhotoImage
                qr_img = qr_img.resize((120, 120))
                self.qr_photo = ImageTk.PhotoImage(qr_img)
                
                # Display QR code
                self.qr_button = tk.Button(
                    qr_frame,
                    image=self.qr_photo,
                    command=self.open_game_page,
                    cursor='hand2',
                    relief='raised',
                    bd=2,
                    bg='#f8f1e0',
                    activebackground='#f8f1e0'
                )
                self.qr_button.pack(pady=2)
                
                # Click instruction
                click_label = tk.Label(
                    qr_frame,
                    text="👆 I-click para buksan",
                    font=('Arial', 8),
                    bg='#f8f1e0',
                    fg='#8b7355'
                )
                click_label.pack()
                
                # URL display
                display_url = self.game_url[:35] + "..." if len(self.game_url) > 35 else self.game_url
                url_label = tk.Label(
                    qr_frame,
                    text=display_url,
                    font=('Arial', 7),
                    bg='#f8f1e0',
                    fg='#7f8c8d',
                    cursor='hand2'
                )
                url_label.pack()
                url_label.bind('<Button-1>', lambda e: self.open_game_page())
                
            except Exception as e:
                self.create_fallback_qr(parent)
        else:
            self.create_fallback_qr(parent)
        
        return qr_frame
    
    def create_fallback_qr(self, parent):
        """Create a fallback QR code display if QR library isn't available"""
        qr_frame = tk.Frame(parent, bg='#f8f1e0')
        qr_frame.pack(pady=5)
        
        # Simple QR placeholder with clickable link
        qr_text = tk.Label(
            qr_frame,
            text="📱 SCAN QR CODE\nOR CLICK HERE",
            font=('Arial', 10, 'bold'),
            bg='#f8f1e0',
            fg='#0032a0',
            cursor='hand2'
        )
        qr_text.pack()
        
        # Make the text clickable
        qr_text.bind('<Button-1>', lambda e: self.open_game_page())
        
        # QR placeholder box
        qr_box = tk.Canvas(
            qr_frame,
            width=120,
            height=120,
            bg='white',
            highlightthickness=2,
            highlightbackground='#0032a0'
        )
        qr_box.pack(pady=2)
        
        # Draw a QR code pattern manually
        self.draw_placeholder_qr(qr_box)
        
        # Click instruction
        click_label = tk.Label(
            qr_frame,
            text="👆 I-click para buksan",
            font=('Arial', 8),
            bg='#f8f1e0',
            fg='#8b7355'
        )
        click_label.pack()
        
        # Install instructions
        install_label = tk.Label(
            qr_frame,
            text="💡 Install: pip install qrcode[pil]",
            font=('Arial', 7),
            bg='#f8f1e0',
            fg='#e74c3c'
        )
        install_label.pack()
    
    def draw_placeholder_qr(self, canvas):
        """Draw a placeholder QR code pattern"""
        size = 120
        block_size = 6
        margin = 10
        
        # Draw position markers (simplified)
        positions = [(margin, margin), (size - margin - 30, margin), (margin, size - margin - 30)]
        
        for x, y in positions:
            # Outer square
            canvas.create_rectangle(
                x, y, x + 30, y + 30,
                fill='#0032a0',
                outline='#0032a0'
            )
            # Inner square
            canvas.create_rectangle(
                x + 6, y + 6, x + 24, y + 24,
                fill='white',
                outline='white'
            )
            # Center dot
            canvas.create_rectangle(
                x + 12, y + 12, x + 18, y + 18,
                fill='#0032a0',
                outline='#0032a0'
            )
        
        # Draw random blocks
        for _ in range(40):
            x = margin + random.randint(0, size - margin - block_size)
            y = margin + random.randint(0, size - margin - block_size)
            # Skip if in position marker areas
            skip = False
            for px, py in positions:
                if (px - 5 <= x <= px + 35) and (py - 5 <= y <= py + 35):
                    skip = True
                    break
            if not skip:
                canvas.create_rectangle(
                    x, y, x + block_size, y + block_size,
                    fill=random.choice(['#0032a0', '#f1c40f', '#ce1126']),
                    outline=''
                )
        
        # Draw a star in the center
        canvas.create_text(
            size // 2, size // 2,
            text='⭐',
            font=('Arial', 20)
        )
        
        # Make the canvas clickable
        canvas.bind('<Button-1>', lambda e: self.open_game_page())
    
    def open_game_page(self):
        """Open the game page in a web browser"""
        if self.game_url:
            try:
                webbrowser.open(self.game_url)
                messagebox.showinfo(
                    "🌐 Binubuksan ang Game Page",
                    f"Binubuksan ang game page sa iyong browser:\n\n{self.game_url}\n\n🇵🇭 Mag-enjoy!"
                )
            except Exception as e:
                messagebox.showerror(
                    "Error",
                    f"Hindi mabuksan ang page:\n{self.game_url}\n\nError: {e}"
                )
        else:
            messagebox.showwarning(
                "Walang URL",
                "Wala pang nakatakdang URL para sa game page.\n\nI-update ang 'game_url' sa code."
            )
    
    def setup_ui(self):
        # === FIESTA BANNER AT THE TOP ===
        self.create_fiesta_banner(self.root)
        
        # === TOP SECTION WITH QR CODE ===
        top_section = tk.Frame(self.root, bg='#f8f1e0')
        top_section.pack(fill='x', pady=(5, 0))
        
        # Title on the left side
        title_frame = tk.Frame(top_section, bg='#f8f1e0')
        title_frame.pack(side='left', fill='both', expand=True)
        
        self.title_label = tk.Label(
            title_frame,
            text="🎯 Hulaan Mo! - Barangay Fiesta Edition",
            font=('Arial', 28, 'bold'),
            bg='#f8f1e0',
            fg='#0032a0'
        )
        self.title_label.pack(pady=(10, 5))
        
        # Subtitle with attempts info
        subtitle_label = tk.Label(
            title_frame,
            text=f"🇵🇭 Hulaan ang numero! (1-100) - {self.max_attempts} na taya",
            font=('Arial', 12),
            bg='#f8f1e0',
            fg='#8b7355'
        )
        subtitle_label.pack(pady=5)
        
        # Prize display
        item_label = tk.Label(
            title_frame,
            text=f"🏆 Premyo: {self.current_item}",
            font=('Arial', 14, 'bold'),
            bg='#f8f1e0',
            fg='#ce1126'
        )
        item_label.pack(pady=5)
        
        # High score display
        if self.high_score:
            high_score_label = tk.Label(
                title_frame,
                text=f"🏅 Pinakamahusay: {self.high_score} taya",
                font=('Arial', 11),
                bg='#f8f1e0',
                fg='#f1c40f'
            )
            high_score_label.pack(pady=2)
            self.high_score_label = high_score_label
        
        # QR Code on the right side
        qr_frame = tk.Frame(top_section, bg='#f8f1e0')
        qr_frame.pack(side='right', padx=20, pady=10)
        self.create_qr_code(qr_frame)
        
        # Store references for updates
        self.item_label = item_label
        
        # === FEEDBACK SECTION ===
        self.feedback_frame = tk.Frame(
            self.root,
            bg='white',
            relief='groove',
            bd=2
        )
        self.feedback_frame.pack(pady=10, padx=20, fill='both')
        
        self.feedback_label = tk.Label(
            self.feedback_frame,
            text="💡 Maglagay ng numero at pindutin ang 'Hulaan'!",
            font=('Arial', 14),
            bg='white',
            fg='#2c3e50',
            wraplength=400,
            pady=20
        )
        self.feedback_label.pack()
        
        # === INPUT SECTION ===
        input_frame = tk.Frame(self.root, bg='#f8f1e0')
        input_frame.pack(pady=10)
        
        # Entry with placeholder
        self.guess_entry = tk.Entry(
            input_frame,
            font=('Arial', 16),
            width=15,
            justify='center',
            relief='solid',
            bd=2
        )
        self.guess_entry.pack(side='left', padx=10)
        self.guess_entry.bind('<Return>', lambda event: self.check_guess())
        self.guess_entry.bind('<Control-a>', lambda e: self.guess_entry.select_range(0, 'end'))
        self.guess_entry.focus()
        
        self.guess_button = tk.Button(
            input_frame,
            text="🎯 Hulaan!",
            font=('Arial', 14, 'bold'),
            bg='#0032a0',
            fg='white',
            padx=20,
            pady=10,
            command=self.check_guess,
            cursor='hand2',
            relief='raised',
            bd=3,
            activebackground='#002a8a',
            activeforeground='white'
        )
        self.guess_button.pack(side='left', padx=10)
        
        # === STATS SECTION ===
        stats_frame = tk.Frame(self.root, bg='#f8f1e0')
        stats_frame.pack(pady=10)
        
        self.attempts_label = tk.Label(
            stats_frame,
            text=f"Taya: 0/{self.max_attempts}",
            font=('Arial', 14),
            bg='#f8f1e0',
            fg='#2c3e50'
        )
        self.attempts_label.pack(side='left', padx=20)
        
        self.range_label = tk.Label(
            stats_frame,
            text="Saklaw: 1 - 100",
            font=('Arial', 14),
            bg='#f8f1e0',
            fg='#2c3e50'
        )
        self.range_label.pack(side='left', padx=20)
        
        # === CONTROL BUTTONS ===
        control_frame = tk.Frame(self.root, bg='#f8f1e0')
        control_frame.pack(pady=15)
        
        self.new_game_button = tk.Button(
            control_frame,
            text="🔄 Maglaro Muli",
            font=('Arial', 12, 'bold'),
            bg='#f1c40f',
            fg='#2c3e50',
            padx=20,
            pady=8,
            command=self.reset_game,
            cursor='hand2',
            relief='raised',
            bd=3,
            activebackground='#d4b00d',
            activeforeground='#2c3e50'
        )
        self.new_game_button.pack(side='left', padx=10)
        
        self.hint_button = tk.Button(
            control_frame,
            text="💡 Pahiwatig",
            font=('Arial', 12, 'bold'),
            bg='#ce1126',
            fg='white',
            padx=20,
            pady=8,
            command=self.give_hint,
            cursor='hand2',
            relief='raised',
            bd=3,
            activebackground='#b00e1f',
            activeforeground='white'
        )
        self.hint_button.pack(side='left', padx=10)

        self.exit_button = tk.Button(
            control_frame,
            text="🚪 Umalis",
            font=('Arial', 12, 'bold'),
            bg='#2c3e50',
            fg='white',
            padx=20,
            pady=8,
            command=self.quit_game,
            cursor='hand2',
            relief='raised',
            bd=3,
            activebackground='#1a252f',
            activeforeground='white'
        )
        self.exit_button.pack(side='left', padx=10)
        
        # === HISTORY SECTION ===
        history_frame = tk.Frame(
            self.root,
            bg='white',
            relief='solid',
            bd=1
        )
        history_frame.pack(pady=10, padx=20, fill='both', expand=True)
        
        history_header = tk.Frame(history_frame, bg='white')
        history_header.pack(fill='x', pady=5)
        
        history_title = tk.Label(
            history_header,
            text="📊 Kasaysayan ng mga Hula",
            font=('Arial', 12, 'bold'),
            bg='white',
            fg='#2c3e50'
        )
        history_title.pack(side='left', padx=10)
        
        # Clear history button
        clear_history_btn = tk.Button(
            history_header,
            text="🗑️ Burahin",
            font=('Arial', 8),
            bg='#e74c3c',
            fg='white',
            padx=10,
            pady=2,
            command=self.clear_history,
            cursor='hand2',
            relief='raised',
            bd=2
        )
        clear_history_btn.pack(side='right', padx=10)
        
        self.history_text = tk.Text(
            history_frame,
            height=6,
            width=40,
            font=('Arial', 10),
            bg='#f8f9fa',
            fg='#2c3e50',
            state='disabled',
            wrap='word'
        )
        self.history_text.pack(pady=5, padx=10)
        
        # === INSTRUCTIONS ===
        instruction_label = tk.Label(
            self.root,
            text="💡 Pindutin ang 'Enter' o 'Hulaan!' para mag-submit | ESC para lumabas sa fullscreen | F11 para mag-toggle",
            font=('Arial', 9),
            bg='#f8f1e0',
            fg='#7f8c8d'
        )
        instruction_label.pack(pady=5)
        
        self.guess_entry.focus()
    
    def clear_history(self):
        """Clear the guess history"""
        self.guess_history = []
        self.history_text.config(state='normal')
        self.history_text.delete('1.0', tk.END)
        self.history_text.config(state='disabled')
    
    def quit_game(self):
        """Quit the game with confirmation"""
        if messagebox.askyesno("Umalis", "Sigurado ka bang gusto mong umalis?\n\nAre you sure you want to quit?"):
            self.root.destroy()
            sys.exit()
    
    def flash_screen(self, color, times=5):
        original_color = '#f8f1e0'
        for i in range(times):
            self.root.configure(bg=color)
            self.root.update()
            self.root.after(100 if i < times-1 else 200)
            self.root.configure(bg=original_color)
            self.root.update()
            self.root.after(100 if i < times-1 else 200)
    
    def start_failure_effects(self):
        self.failure_effects_active = True
        self.play_sound(self.boom_sound)
        
        failure_colors = ['#ce1126', '#0032a0', '#ce1126', '#0032a0', '#ce1126']
        for color in failure_colors:
            self.root.configure(bg=color)
            self.root.update()
            self.root.after(80)
            self.root.configure(bg='#f8f1e0')
            self.root.update()
            self.root.after(80)
        
        self.start_failure_particles()
        
        self.feedback_label.config(
            text="💥 TALO! GAME OVER! 💥\nAng numero ay " + str(self.secret_number),
            fg='#ce1126',
            font=('Arial', 18, 'bold')
        )
        
        for _ in range(3):
            self.feedback_frame.config(bg='#ce1126')
            self.root.update()
            self.root.after(150)
            self.feedback_frame.config(bg='white')
            self.root.update()
            self.root.after(150)
        
        messagebox.showerror(
            "💥 TALO! 💥", 
            f"😱 NAKAKAPANGHINAYANG! 😱\n\nAng numero ay {self.secret_number}\n\n💀 Subukan muli! 💀\n\nPindutin ang 'Maglaro Muli' para subukan ulit!"
        )
        
        self.failure_effects_active = False
    
    def start_failure_particles(self):
        particles = []
        colors = ['#ce1126', '#0032a0', '#f1c40f', '#ce1126', '#0032a0', '#f1c40f']
        
        for _ in range(80):
            angle = random.uniform(0, 2 * 3.14159)
            speed = random.uniform(2, 10)
            particles.append({
                'x': self.screen_width // 2,
                'y': self.screen_height // 2,
                'vx': speed * np.cos(angle),
                'vy': speed * np.sin(angle) - 2,
                'size': random.randint(5, 15),
                'color': random.choice(colors),
                'life': random.randint(20, 50),
                'gravity': 0.1
            })
        
        particle_canvas = tk.Canvas(
            self.root,
            width=self.screen_width,
            height=self.screen_height,
            bg='#f8f1e0',
            highlightthickness=0
        )
        particle_canvas.place(x=0, y=0)
        tk.Misc.lift(particle_canvas)
        
        def animate_particles():
            nonlocal particles
            particle_canvas.delete('particle')
            
            for p in particles[:]:
                p['x'] += p['vx']
                p['y'] += p['vy']
                p['vy'] += p['gravity']
                p['life'] -= 1
                
                if p['life'] <= 0 or p['y'] > self.screen_height:
                    particles.remove(p)
                    continue
                
                x, y = int(p['x']), int(p['y'])
                size = p['size']
                color = p['color']
                
                particle_canvas.create_oval(
                    x - size//2, y - size//2,
                    x + size//2, y + size//2,
                    fill=color,
                    outline=color,
                    tags='particle'
                )
            
            if particles:
                self.root.after(30, animate_particles)
            else:
                particle_canvas.destroy()
        
        animate_particles()
    
    def start_confetti(self):
        self.stop_confetti()
        
        self.confetti_active = True
        self.confetti_particles = []
        
        colors = ['#ce1126', '#0032a0', '#f1c40f', '#ce1126', '#0032a0', '#ffffff']
        for _ in range(150):
            self.confetti_particles.append({
                'x': random.randint(0, self.screen_width),
                'y': random.randint(-200, -20),
                'size': random.randint(5, 20),
                'speed': random.uniform(2, 6),
                'color': random.choice(colors),
                'drift': random.uniform(-2, 2)
            })
        
        if not hasattr(self, 'confetti_canvas'):
            self.confetti_canvas = tk.Canvas(
                self.root,
                width=self.screen_width,
                height=self.screen_height,
                bg='#f8f1e0',
                highlightthickness=0
            )
            self.confetti_canvas.place(x=0, y=0)
            tk.Misc.lift(self.confetti_canvas)
        
        self.animate_confetti()
    
    def animate_confetti(self):
        if not self.confetti_active:
            return
        
        if not hasattr(self, 'confetti_canvas'):
            return
        
        try:
            self.confetti_canvas.delete('confetti')
            
            for particle in self.confetti_particles:
                particle['y'] += particle['speed']
                particle['x'] += particle['drift']
                
                if particle['y'] > self.screen_height:
                    particle['y'] = random.randint(-200, -20)
                    particle['x'] = random.randint(0, self.screen_width)
                    particle['speed'] = random.uniform(2, 6)
                
                x, y = int(particle['x']), int(particle['y'])
                size = particle['size']
                color = particle['color']
                
                if random.random() > 0.5:
                    self.confetti_canvas.create_rectangle(
                        x - size//2, y - size//2,
                        x + size//2, y + size//2,
                        fill=color,
                        outline=color,
                        tags='confetti'
                    )
                else:
                    self.confetti_canvas.create_oval(
                        x - size//2, y - size//2,
                        x + size//2, y + size//2,
                        fill=color,
                        outline=color,
                        tags='confetti'
                    )
            
            if self.confetti_active:
                self.confetti_animation_id = self.root.after(30, self.animate_confetti)
                
        except Exception as e:
            print(f"Confetti animation error: {e}")
            self.stop_confetti()
    
    def stop_confetti(self):
        self.confetti_active = False
        
        if hasattr(self, 'confetti_animation_id') and self.confetti_animation_id:
            try:
                self.root.after_cancel(self.confetti_animation_id)
                self.confetti_animation_id = None
            except:
                pass
        
        if hasattr(self, 'confetti_canvas'):
            try:
                self.confetti_canvas.destroy()
                delattr(self, 'confetti_canvas')
            except:
                pass
        
        self.confetti_particles = []
    
    def get_filipino_number(self, num):
        if num in self.filipino_numbers:
            return self.filipino_numbers[num]
        
        tens = (num // 10) * 10
        ones = num % 10
        
        if tens == 0:
            return self.filipino_numbers[ones]
        elif ones == 0:
            return self.filipino_numbers[tens]
        else:
            return f"{self.filipino_numbers[tens]} at {self.filipino_numbers[ones]}"
    
    def check_guess(self):
        if self.game_over:
            messagebox.showinfo("Tapos na ang Laro", "Magsimula ng bagong laro!")
            return
        
        try:
            guess = int(self.guess_entry.get())
            if guess < 1 or guess > 100:
                messagebox.showwarning("Di Wasto", "Maglagay ng numero sa pagitan ng 1 at 100!")
                self.guess_entry.delete(0, tk.END)
                return
            
            self.play_guess_sound()
            
            self.attempts += 1
            remaining = self.max_attempts - self.attempts
            
            if guess < self.secret_number:
                feedback = f"📈 MASYADONG MABABA! Mas mataas pa."
                color = '#ce1126'
            elif guess > self.secret_number:
                feedback = f"📉 MASYADONG MATAAS! Mas mababa pa."
                color = '#ce1126'
            else:
                # WIN!
                feedback = f"🎉 NANALO KA! {self.attempts} taya ang ginamit mo!"
                color = '#f1c40f'
                self.game_over = True
                self.guess_button.config(state='disabled')
                self.feedback_label.config(text=feedback, fg=color)
                self.update_history(guess, "🎯 TAMA!")
                self.update_attempts_display()
                
                # Check high score
                if not self.high_score or self.attempts < self.high_score:
                    self.high_score = self.attempts
                    self.save_high_score(self.high_score)
                    if hasattr(self, 'high_score_label'):
                        self.high_score_label.config(text=f"🏅 Pinakamahusay: {self.high_score} taya")
                    messagebox.showinfo(
                        "🏆 BAGONG RECORD!",
                        f"🎉 Bagong pinakamahusay na record!\n{self.attempts} taya lamang!\n\n🇵🇭 Mabuhay!"
                    )
                
                self.play_win_sound()
                
                messagebox.showinfo(
                    "🎉 NANALO KA!", 
                    f"Congratulations!\nNakuha mo ang numero sa {self.attempts} taya!\n\n🍽️ Napanalunan mo ang {self.current_item}!"
                )
                
                self.root.after(5000, self.stop_confetti)
                return
            
            self.update_attempts_display()
            
            guess_word = self.get_filipino_number(guess)
            if guess < self.secret_number:
                self.update_history(guess, "⬆️ MABABA")
            else:
                self.update_history(guess, "⬇️ MATAAS")
            
            if remaining > 0:
                self.feedback_label.config(text=f"{feedback} (Natitira: {remaining} taya)", fg=color)
            else:
                # LOSE!
                self.feedback_label.config(
                    text=f"💥 TALO! GAME OVER! 💥",
                    fg='#ce1126',
                    font=('Arial', 16, 'bold')
                )
                self.game_over = True
                self.guess_button.config(state='disabled')
                self.play_lose_sound()
                return
            
            self.guess_entry.delete(0, tk.END)
            self.guess_entry.focus()
            
        except ValueError:
            messagebox.showwarning("Di Wasto", "Maglagay ng wastong numero!")
            self.guess_entry.delete(0, tk.END)
    
    def update_attempts_display(self):
        self.attempts_label.config(text=f"Taya: {self.attempts}/{self.max_attempts}")
    
    def update_history(self, guess, result):
        self.history_text.config(state='normal')
        guess_word = self.get_filipino_number(guess)
        self.guess_history.append(f"▶ {guess} ({guess_word}) - {result}")
        self.history_text.insert('1.0', f"▶ {guess} ({guess_word}) - {result}\n")
        self.history_text.config(state='disabled')
        self.history_text.see('1.0')
    
    def give_hint(self):
        if self.game_over:
            messagebox.showinfo("Tapos na ang Laro", "Magsimula ng bagong laro para sa pahiwatig!")
            return
        
        self.play_hint_sound()
        
        hints = []
        
        if self.secret_number % 2 == 0:
            hints.append("📌 Ang numero ay even (pantay).")
        else:
            hints.append("📌 Ang numero ay odd (di-pantay).")
        
        if self.secret_number > 50:
            hints.append("📌 Ito ay higit sa 50.")
        else:
            hints.append("📌 Ito ay 50 pababa.")
        
        if self.attempts >= 5:
            if self.secret_number % 5 == 0:
                hints.append("📌 Ang numero ay divisible sa 5.")
            if self.secret_number % 3 == 0:
                hints.append("📌 Ang numero ay divisible sa 3.")
        
        if self.secret_number <= 10:
            hints.append(f"📌 Pahiwatig: Ito ay {self.get_filipino_number(self.secret_number)}.")
        
        hint_message = "\n".join(hints) if hints else "📌 Walang karagdagang pahiwatig sa ngayon."
        
        # Random Filipino saying for motivation
        sayings = [
            "🇵🇭 'Ang tiyaga ay katumbas ng tagumpay!'",
            "🇵🇭 'Kung may tiyaga, may nilaga.'",
            "🇵🇭 'Nasa Diyos ang awa, nasa tao ang gawa.'",
            "🇵🇭 'Ang hindi marunong lumingon sa pinanggalingan ay hindi makakarating sa paroroonan.'"
        ]
        
        messagebox.showinfo(
            "💡 Pahiwatig", 
            f"📌 Mga Pahiwatig:\n\n{hint_message}\n\n{random.choice(sayings)}"
        )
    
    def reset_game(self):
        self.stop_confetti()
        
        self.secret_number = random.randint(1, 100)
        self.attempts = 0
        self.game_over = False
        self.guess_button.config(state='normal')
        
        self.current_item = random.choice(self.filipino_items)
        self.item_label.config(text=f"🏆 Premyo: {self.current_item}")
        
        self.feedback_label.config(
            text="💡 Bagong laro! Maglagay ng numero at pindutin ang 'Hulaan'!",
            fg='#2c3e50',
            font=('Arial', 14)
        )
        self.feedback_frame.config(bg='white')
        self.update_attempts_display()
        self.clear_history()
        self.guess_entry.delete(0, tk.END)
        self.guess_entry.focus()
        self.play_sound(self.newgame_sound)
        self.pulse_effect()
        messagebox.showinfo(
            "Bagong Laro", 
            f"🇵🇭 Bagong laro!\nHulaan ang numero sa pagitan ng 1 at 100.\n\n🏆 Premyo: {self.current_item}"
        )

if __name__ == "__main__":
    root = tk.Tk()
    game = FilipinoGuessingGame(root)
    root.mainloop()